package br.com.contaazul.challengerobot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengerobotApplicationTests {

	@Test
	void contextLoads() {
	}

}
